/**
 * 知序 · 云同步（Netlify Blobs）
 * 路由：/api/sync
 *
 * 用法（无账号体系，靠「同步码」隔离）：
 *   POST { action: 'push', code: '我的同步码', data: { version, cards, settings } }
 *   POST { action: 'pull', code: '我的同步码' }
 *   POST { action: 'info', code: '我的同步码' }
 *
 * 安全说明：同步码由用户自己保管，知道码的人就能读写该份数据；请用足够长的随机码。
 */
const crypto = require('node:crypto');

function storeFor(code) {
  // 延迟加载，避免未安装依赖时整个函数加载失败
  const { getStore } = require('@netlify/blobs');
  const hash = crypto.createHash('sha256').update(String(code)).digest('hex').slice(0, 32);
  const opts = { name: 'zhixu-sync', consistency: 'strong' };
  const siteID = process.env.NETLIFY_BLOBS_SITE_ID || process.env.NETLIFY_SITE_ID || '';
  const token = process.env.NETLIFY_BLOBS_TOKEN || process.env.NETLIFY_API_TOKEN || '';
  if (siteID) opts.siteID = siteID;
  if (token) opts.token = token;
  return { store: getStore(opts), key: 'zhixu-' + hash };
}

exports.handler = async function (event) {
  const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };
  const done = (code, payload) => ({ statusCode: code, headers, body: JSON.stringify(payload) });

  if (event.httpMethod !== 'POST') return done(405, { ok: false, error: '只支持 POST' });

  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch (e) { return done(400, { ok: false, error: '请求体不是合法 JSON' }); }

  const action = String(body.action || '').trim();
  const code = String(body.code || '').trim();
  if (code.length < 8) return done(400, { ok: false, error: '同步码至少 8 位' });
  if (code.length > 128) return done(400, { ok: false, error: '同步码太长' });
  if (['push', 'pull', 'info'].indexOf(action) < 0) return done(400, { ok: false, error: 'action 必须是 push/pull/info' });

  let s;
  try {
    s = storeFor(code);
  } catch (e) {
    return done(500, { ok: false, error: '云存储不可用：' + String(e.message || e) });
  }

  try {
    if (action === 'push') {
      const data = body.data;
      if (!data || !Array.isArray(data.cards)) return done(400, { ok: false, error: 'data.cards 必须是数组' });
      const payload = { data: data, updatedAt: new Date().toISOString(), count: data.cards.length };
      await s.store.setJSON(s.key, payload);
      return done(200, { ok: true, updatedAt: payload.updatedAt, count: payload.count });
    }

    if (action === 'pull') {
      const v = await s.store.get(s.key, { type: 'json' });
      if (!v) return done(200, { ok: true, data: null, note: '云端还没有数据，先点「上传」' });
      return done(200, { ok: true, data: v.data, updatedAt: v.updatedAt, count: v.count });
    }

    const meta = await s.store.getMetadata(s.key).catch(() => null);
    return done(200, { ok: true, exists: Boolean(meta), meta: meta || null });
  } catch (e) {
    return done(500, { ok: false, error: String((e && e.message) || e) });
  }
};
